import java.util.HashMap;
import java.util.concurrent.CountDownLatch;

class LeseTrad implements Runnable {
    private final String FILNAVN;
    int id;
    Monitor1 monitor;
    private CountDownLatch counter;

    LeseTrad(int id, String filnavn, Monitor1 monitor, CountDownLatch counter) {
        this.FILNAVN = filnavn;
        this.id = id;
        this.monitor = monitor;
        this.counter = counter;
    }

    @Override
    public void run() {
        System.out.println(String.format("Lesetraad %s starter", this.id));
        HashMap<String, Subsekvens> kart;
        kart = Monitor1.LesFraFil(FILNAVN);
        monitor.settInnHashMap(kart);
        System.out.println(String.format("Lesetraad %s ferdig", this.id));
        counter.countDown();
        // leser fra fil og setter hashmap inn i monitoren
    }
}
