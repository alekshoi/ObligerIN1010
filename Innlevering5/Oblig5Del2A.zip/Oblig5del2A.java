import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;
import java.util.concurrent.CountDownLatch;

class TestDel2A {
    static Monitor1 gaaGjennomFil(String mappe) throws InterruptedException, IOException {
        Monitor1 monitor = new Monitor1();
        Scanner fil = null;
        String filnavn = mappe + "/metadata.csv";
        File filen = new File(filnavn);
        try {
            fil = new Scanner(filen);
        } catch (FileNotFoundException exception) {
            System.out.println(filnavn);
            System.out.println("Fant ikke filen");

            System.exit(1);
        }
        String linje = "";
        ArrayList<Thread> threads = new ArrayList<>();
        Path pathen = Paths.get(filnavn);
        long antallLinjer = Files.lines(pathen).count();
        CountDownLatch barriere = new CountDownLatch((int) antallLinjer - 1);
        while (fil.hasNextLine()) {
            int id = threads.size() + 1;
            linje = fil.nextLine();
            String path = String.format("%s/%s", mappe, linje);
            Runnable lesetrad = new LeseTrad(id, path, monitor, barriere);
            Thread traad = new Thread(lesetrad);
            traad.start();
            threads.add(traad);
        }
        for (int i = 0; i < threads.size(); i++)
            threads.get(i).join();

        while (monitor.antallHashMaps() > 1) {
            HashMap<String, Subsekvens> vaartHashMap = Monitor1.slaaSammenMaps(monitor.hentUtHashMap(),
                    monitor.hentUtHashMap());
            monitor.settInnHashMap(vaartHashMap);
        }
        return monitor;
    }

    static void skrivUtSubsekvensMedFlestForekomster(Monitor1 monitor) {
        int antallForSekvensMedFlestForekomster = 0;
        Subsekvens subsekvensMedFlestForekomster = null;

        for (HashMap<String, Subsekvens> hashmap : monitor.listeOverHashMap) {
            for (Subsekvens value : hashmap.values()) {
                if (value.hentAntallForekomster() > antallForSekvensMedFlestForekomster) {
                    antallForSekvensMedFlestForekomster = value.hentAntallForekomster();
                    subsekvensMedFlestForekomster = value;
                }
            }
        }
        System.out.println("Den sekvensen med flest forekomster i mappen testdatalike var: "
                + subsekvensMedFlestForekomster.subsekvens + " med " + antallForSekvensMedFlestForekomster
                + " forekomster.");
    }

    public static void main(String[] args) throws InterruptedException, IOException {
        Monitor1 monitorTestDataLike = gaaGjennomFil("testdatalike");
        Monitor1 monitorTestDataLitenLike = gaaGjennomFil("testdatalitenlike");
        skrivUtSubsekvensMedFlestForekomster(monitorTestDataLike);
        skrivUtSubsekvensMedFlestForekomster(monitorTestDataLitenLike);
    }
}
