import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;


class Subsekvens{
    public final String subsekvens;
    private int antallForekomsterAvSekvens;
    public Subsekvens(String subsekvens, int antallForekomsterAvSekvens){
        this.subsekvens = subsekvens;
        this.antallForekomsterAvSekvens = antallForekomsterAvSekvens;
    }   
    public int hentAntallForekomster(){
        return antallForekomsterAvSekvens;
    }
    public void endreAntallForekomster(int tall){
        antallForekomsterAvSekvens = tall;
    }
    @Override
    public String toString() {
        return "(" + subsekvens + "," + antallForekomsterAvSekvens + ")\n";
    }
}
class SubsekvensRegister{
    ArrayList<HashMap<String, Subsekvens>> listeOverHashMap = new ArrayList<>();
    public void settInnHashMap(HashMap<String, Subsekvens> map){
        listeOverHashMap.add(map);
    }
    public HashMap<String, Subsekvens> hentUtHashMap(){
        // returnerer ingenting hvis listen er tom
        if(listeOverHashMap.isEmpty()){
            return null;
        }
        else{
            // returnerer første hashmap i hashmapen
            return listeOverHashMap.remove(0);
        }
    }
    public int antallHashMaps(){
        return listeOverHashMap.size();
    }
    public static HashMap<String, Subsekvens> LesFraFil(String filnavn){
        Scanner fil = null;
        File filen = new File(filnavn);
        try {
            fil = new Scanner(filen);
        } catch (FileNotFoundException exception) {
            System.out.println("Fant ikke filen");
            System.exit(1);
        }
        String linje = "";
        HashMap<String, Subsekvens> nyHashMap = new HashMap<String, Subsekvens>();
        while (fil.hasNextLine()){
            linje = fil.nextLine();
            int counter = 0;
            char[] liste = linje.toCharArray();
            // vi bruker counter som indexen på en character i linja. Når vi nærmer oss slutten av linja, må vi passe på at vi ikke får en nullpointer
            // i og med at vi kaller på liste[counter+2] i while-løkken må vi passe på at indextallet ikke er større enn den høyeste indexen
            // vi skulle også stoppe løkken hvis linjen er har en lengde under 3. 
            while(counter+2<=liste.length-1 && liste.length>=3){
                String subsekvensen = "" + liste[counter] +  liste[counter+1] +  liste[counter+2];
                // hvis hashMapen ikke inneholder subsekvensen, legger vi den inn med en forekomst på 1 
                if(!(nyHashMap.containsKey(subsekvensen))){
                    nyHashMap.put(subsekvensen, new Subsekvens(subsekvensen, 1));
                }
                counter++;
            }
        }
        return nyHashMap;
    }
    public static HashMap<String, Subsekvens> slaaSammenMaps(HashMap<String, Subsekvens> hashmap1, HashMap<String, Subsekvens> hashmap2){
        // hvis en av hashmapene er tomme returnerer vi den andre, med mindre begge er tomme
        if (hashmap1.isEmpty() && hashmap2.isEmpty()){
            return null;
        }
        if(hashmap1.isEmpty()){
            return hashmap2;
        }
        if(hashmap2.isEmpty()){
            return hashmap1;
        }
        HashMap<String, Subsekvens> nyttHashMap = new HashMap<>();
        
        // sammenligner hver verdi fra hashmap1 med hver verdi hashmap2
        for (String keyHashMap1: hashmap1.keySet()){ 
            for(String keyHashMap2: hashmap2.keySet()){
                // legger til elementet hvis ikke hashmap1 inneholder subsekvensen. 
                if(!hashmap1.containsKey(keyHashMap2)){
                    nyttHashMap.put(keyHashMap2, new Subsekvens(keyHashMap2, 1));
                }
                if (keyHashMap1.equals(keyHashMap2)){
                    //her regner vi ikke med at det kan være duplikater
                    int antallTilSammen = 0;
                    Subsekvens subsekvens1 = hashmap1.get(keyHashMap1);
                    Subsekvens subsekvens2 = hashmap2.get(keyHashMap2);
                    // sjekker sammenlagt forekomst og legger til i hashmapen
                    antallTilSammen += subsekvens1.hentAntallForekomster() + subsekvens2.hentAntallForekomster();
                    nyttHashMap.put(keyHashMap1, new Subsekvens(keyHashMap1, antallTilSammen));
                }
            }
            // legger til elementet hvis ikke hashmap2 inneholder subsekvensen. 
            if(!hashmap2.containsKey(keyHashMap1)){
                nyttHashMap.put(keyHashMap1, new Subsekvens(keyHashMap1, 1));
            }
        }
        return nyttHashMap;
    }
}
