import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Scanner;
import java.util.concurrent.CountDownLatch;

class Oblig5Del2B {
    private final static int antallFletteTraader = 5;
    private final static String mappeSomSkalTestes = "testdatalike";

    static Monitor2 gaaGjennomFil(String mappe) throws InterruptedException, IOException {
        Monitor2 monitor = new Monitor2();
        Scanner fil = null;
        String filnavn = String.format("%s/metadata.csv", mappe);
        File filen = new File(filnavn);
        try {
            fil = new Scanner(filen);
        } catch (FileNotFoundException exception) {
            System.out.println(String.format("Fant ikke filen, sjekk mappen %s", mappe));
            throw exception;
        }
        String linje = "";
        Path pathen = Paths.get(filnavn);
        // finner antall linjer i filen, altså hvor mange filer den skal gå gjennom.
        long antallLinjer = Files.lines(pathen).count();
        CountDownLatch leseTradCounter = new CountDownLatch((int) antallLinjer - 1);

        // oppretter en tråd for hver fil. Tråden legger inn hashmap i monitor2 sin
        // liste
        int id = 1;
        while (fil.hasNextLine()) {
            linje = fil.nextLine();
            String path = String.format("%s/%s", mappe, linje);
            System.out.println(String.format("Leser fil %s", path));
            Runnable lesetrad = new LeseTrad(id, path, monitor, leseTradCounter);
            Thread traad = new Thread(lesetrad);
            traad.start();
            id++;
        }

        // imens lesetrådene legger til i hashmapet, skal flettetråden flette de
        // eksisterende hashmapene sammen
        // her velger man selv hvor mange tråder man vil bruke
        CountDownLatch fletteTradCounter = new CountDownLatch(antallFletteTraader);
        for (int i = 0; i < antallFletteTraader; i++) {
            int tradId = i + 1;
            Runnable flettetrad = new FletteTrad(tradId, monitor, fletteTradCounter, leseTradCounter);
            Thread trad = new Thread(flettetrad);
            trad.start();
        }
        // venter til de har gjort seg ferdige med å gi ut melding om at de er ferdige
        leseTradCounter.await();
        System.out.println("Alle lesetraader er ferdige.");
        fletteTradCounter.await();
        System.out.println("Alle flettetraader er ferdige.");
        fil.close();
        return monitor;
    }

    static void skrivUtSubsekvensMedFlestForekomster(Monitor2 monitor) {
        // går gjennom alle hashmapene og finner subsekvens med flest forekomster
        int antallForSekvensMedFlestForekomster = 0;
        Subsekvens subsekvensMedFlestForekomster = null;

        for (HashMap<String, Subsekvens> hashmap : monitor.hentArrayListe()) {
            for (Subsekvens value : hashmap.values()) {
                if (value.hentAntallForekomster() > antallForSekvensMedFlestForekomster) {
                    antallForSekvensMedFlestForekomster = value.hentAntallForekomster();
                    subsekvensMedFlestForekomster = value;
                }
            }
        }
        System.out.println("Den sekvensen med flest forekomster i mappen testdatalike var: "
                + subsekvensMedFlestForekomster.subsekvens + " med " + antallForSekvensMedFlestForekomster
                + " forekomster.");
    }

    public static void main(String[] args) throws InterruptedException, IOException {
        System.out.println(String.format("Test for filer i %s \n", mappeSomSkalTestes));
        Monitor2 monitorTestData = gaaGjennomFil(mappeSomSkalTestes);
        skrivUtSubsekvensMedFlestForekomster(monitorTestData);

    }
}