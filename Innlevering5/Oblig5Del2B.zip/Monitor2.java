import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

class Monitor2 extends Monitor1 {
    static Lock laas = new ReentrantLock(true);
    Condition MangeNokHashMaps = laas.newCondition();
    private final int faerrestAntallHashMapMulig = 2;

    // henter supermetoder, men setter lås på
    @Override
    public void settInnHashMap(HashMap<String, Subsekvens> hashmap) {
        laas.lock();
        try {
            super.settInnHashMap(hashmap);
            MangeNokHashMaps.signalAll();
        } finally {
            laas.unlock();
        }
    }

    public ArrayList<HashMap<String, Subsekvens>> hentUtTo(boolean leseTraderFerdig) throws InterruptedException {
        laas.lock();
        try {
            ArrayList<HashMap<String, Subsekvens>> hashMapSomSkalReturneres = new ArrayList<>();
            while (antallHashMaps() < faerrestAntallHashMapMulig) {
                // hvis lesetråder er ferdig og det ikke er mange nok hashmap i listen, skal den
                // returnere den tomme listen
                if (leseTraderFerdig) {
                    return hashMapSomSkalReturneres;
                }
                // hvis det ikke er mange nok hashMaper i listen, skal den vente på at
                // lesetråden legger inn flere som den kan flette
                MangeNokHashMaps.await();
            }
            // henter ut de to første hashmapene og returnerer en liste med disse to.
            hashMapSomSkalReturneres.add(super.hentUtHashMap());
            hashMapSomSkalReturneres.add(super.hentUtHashMap());

            return hashMapSomSkalReturneres;
        } finally {
            laas.unlock();
        }
    }
}