import java.util.HashMap;
import java.util.concurrent.CountDownLatch;

class LeseTrad implements Runnable {
    private final String FILNAVN;
    int id;
    Monitor2 monitor;
    private CountDownLatch counter;

    LeseTrad(int id, String filnavn, Monitor2 monitor, CountDownLatch counter) {
        this.id = id;
        this.FILNAVN = filnavn;
        this.monitor = monitor;
        this.counter = counter;
    }

    @Override
    public void run() {
        // leser fra fil og setter hashmap inn i monitoren
        System.out.println(String.format("Lesetraad %s starter", this.id));
        HashMap<String, Subsekvens> kart;

        try {
            kart = Monitor2.LesFraFil(FILNAVN);
            monitor.settInnHashMap(kart);
        } catch (Exception e) {
            e.printStackTrace();
        }
        counter.countDown();
    }
}
